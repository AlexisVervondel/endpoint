#!/usr/bin/env bash

# run this script only as root user
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root" 
   exit 1
fi

echo "This script was run as root"

# parse arguments
while test "$#" -gt 0; do
	case "$1" in
		"-l")
			exec 1> collect.log
			exec 2>&1
			shift
		;;
		"-dpi")
			dpi=1
			shift
		;;
		*)
			TMP_DIR=$1
			shift
		;;
	esac
done

if [ "$TMP_DIR" = "" ]; then
	TMP_DIR=/tmp/epp_logs
fi
mkdir -p "$TMP_DIR" && cd "$TMP_DIR" || exit 1

check()
{
	if command -v "$1" > /dev/null 2>&1; then
		return 0
	else
		>&2 echo "Command '$1' not found"
		return 1
	fi
}

if [ "$dpi" = "1" ]; then
	check "lsof" && {
		echo "ALL connections and applications"
		lsof > all_connections_and_app.txt 2>&1
	}


	check "ss" && {
		echo "Listing TCP connections and listening ports"
		#netstat -a -b -n > netstat.txt
		ss -a -i -n > netstat.txt 2>&1


		echo "Saving networking statistics"
		#netstat -s > netstat_stats.txt 2>&1
		ss -s > netstat_stats.txt 2>&1


		echo "ESTABLISHED connection and applications"
		ss -tunp | grep "ESTAB" > established_connections.txt 2>&1


		echo "LISTEN ports and applications"
		ss -tulnp | grep "LISTEN" > listen_apps.txt 2>&1
	}


	check "ip" && {
		echo "All network interfaces"
		#ifconfig -v > interfaces.txt 2>&1
		ip a > interfaces.txt 2>&1


		echo "Saving the routing table"
		#netstat -rn > netstat_routing.txt 2>&1
		ip r > netstat_routing.txt 2>&1
	}


	check "journalctl" && {
		echo "Listing all console logs from last 10 minutes"
		#echo "This command can take several minutes to complete, don't interrupt."
		#log show --info --last 10m > last_10_minutes_console_logs.log 2>&1
		journalctl -S -10m > last_10_minutes_console_logs.log 2>&1
	}


	check "iptables" && {
		echo "iptables rules"
		for table in filter nat mangle raw security; do
			{
				echo "--- $table ---"
				echo
				iptables -t "$table" -nvL 2>&1
				echo
				iptables -t "$table" -vS 2>&1
				echo
			} >> iptables.txt
		done
	}


	check "nft" && {
		echo "nft rules"
		nft list ruleset > nft.txt 2>&1
	}


	check "lsmod" && {
		echo "list modules"
		lsmod > lsmod.txt 2>&1
	}


	check "ls" && {
		echo "list /etc/ssl"
		ls -alR /etc/ssl > etc_ssl.txt 2>&1
	}


	check "certutil" && {
		echo "list users certificates"
		find /home -name cert9.db 2>/dev/null | while read -r line; do
			dir="$(dirname "$line")"
			echo "$dir"
			NSS_DEFAULT_DB_TYPE=sql certutil -L -d "$dir"
		done > certutil.txt 2>&1
	}

	if test -f "/var/opt/cososys/epp-client/netdlp/netdlp_settings.json"; then
		cp /var/opt/cososys/epp-client/netdlp/netdlp_settings.json ./netdlp_settings.json
	fi

	if test -f "/var/opt/cososys/epp-client/netdlp/bypass_state.db"; then
		cp /var/opt/cososys/epp-client/netdlp/bypass_state.db ./bypass_state.db
	fi

	if test -f "/var/log/epp-client/eppsslsplit.log"; then
		cp /var/log/epp-client/eppsslsplit.log .
	fi
fi


check "ps" && {
	echo "Listing all running processes"
	ps aux > tasklist.txt
}


# TODO? *.desktop


check "snap" && {
	echo "snaps"
	snap list > snap.txt 2>&1
}


check "flatpak" && {
	echo "flatpaks"
	flatpak list > flatpak.txt 2>&1
}


#TODO appimages


check "dpkg" && {
	echo "deb packages"
	dpkg -l > dpkg.txt 2>&1
}


check "yum" && {
	echo "yum packages"
	yum list installed > yum.txt 2>&1
}


check "dnf" && {
	echo "dnf packages"
	dnf list installed > dnf.txt 2>&1
}


check "zypper" && {
	echo "zypper packages"
	zypper search -i > zypper.txt 2>&1
}

if test -f "/opt/cososys/share/apps/epp-client/options.ini"; then
    cp /opt/cososys/share/apps/epp-client/options.ini ./options.ini
fi

if test -d "/var/log/epp-client"; then
    cp /var/log/epp-client/epp_client_daemon*.log .
fi

exit 0
